// Vuex 중앙집중식 상태관리 라이브러리
import { createStore } from "vuex";


export default createStore({
    // state: 실제로 취급하는 데이터 혹은 전역적으로 사용되는 데이터
    state:{
        cityName: "이 state는 테스트 데이터 입니다.",
        num1: 0,
    },
    mutations: {
        increment(state){
            
            state.num1++;
        },
        changeCityName(state){
            state.cityName = "뮤테이션이 동작한 뒤의 데이터입니다.";
        },
    },
    getters: {
        // 기본 컴포넌트에서 사용되는 computed 속성과 동일하다.
        changeCityName(state){
            return state.cityName.split(" ").join();
        },
    },
    actions: {
        increment(context) {
            // 로직을 관리하는 역할이 더 크다. 이것에 더 중점을 두고 있다.
            context.commit('increment', payload);

            // actions에서 mutations처럼 state를 바로 불러올 순 없다.
            // context라는 객체 데이터를 호출을 해서, 가지고 와서 context를 참조하여 데이터를 불러온다.
            // context에는 state, getters, mutations를 활용할 수 있는 데이터를 담고 있다.

            // 객체구조분해 방법으로 불러올 수도 있다.
            // ex) functionName( { state, getters, commit } ){}
        // 함수가 실행될 때, 두 번째 매개변수 자리는 인자로 들어온 특정한 데이터를 payload라는 이름으로 받는다.
        },
    },
});