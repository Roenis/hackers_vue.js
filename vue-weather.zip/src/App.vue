<template>
  <RouterView />
</template>

<script>

export default {
  data () {
    

    return {};
  },
};
</script>

<style>
body{
  margin:0;
  padding: 0;
}

</style>