<template>
 <h1>{{ this.$store.state.cityName }}</h1>
 <h1>{{ this.$store.state.num1 }}</h1>
 <button @click="changeState">버튼 1</button>
 <button @click="increment">버튼 2</button>
</template>

<script>
import MAINPAGE from "@components/organisms/index.vue"
export default {
    components: {
        MAINPAGE,
    },
    data () {
        

        return {};
    },
    methods:{
        changeState(){
            this.$store.commit("changeCityName");
        },
        increment(){
            this.$store.commit("increment");
        },
    },
};
</script>

<style lang="scss" scoped>
@import "@assets/styles/main.scss";
.page{
    width: 100vw;
    height: 100vh;

    background-color: $color-white-100;
}
</style>