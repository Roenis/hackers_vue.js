import { createRouter, createWebHashHistory } from "vue-router";
import Home from "@pages/index.vue";

export default createRouter({
    history: createWebHashHistory(),
    // 페이지를 구분해주는 개념
    routes: [
        {
            path: "/",
            name: "home",
            component: Home,
        },
    ],
});