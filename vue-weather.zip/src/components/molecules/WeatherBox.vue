<template>
    <div class="weather-box">
        <div class="weather-box__icon-box">
            <div class="weather-box__icon-box__info">
                <span class="temp">{{ Math.round(currentTemp) + "&deg;C" }}</span>
                <span class="desc">{{currentDesc}}</span>
                <span class="update">Updated 1:48pm</span>
            </div>
            <img 
                :src="`src/assets/images/${currentWeatherIcon}.png`" alt="" class="weather-box__icon-box__icon"/>
        </div>
        <div class="weather-box__detail">
            <span class="weather-box__detail__item">
                Barometer: {{ currentBarometer }}
            </span>
            <span class="weather-box__detail__item">
                Feels Like: {{ Math.round(currentFeelsLike) + "&deg;C" }}
            </span>
            <span class="weather-box__detail__item">
                Humidity: {{ currentHumidity }}
            </span>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
export default {
    data () {
        return {
            currentTemp:"",
            currentDesc:"",
            currentBarometer:"",
            currentFeelsLike:"",
            currentHumidity:"",
            currentWeatherIcon: "",
        };
    },
    async created(){
        // f8816e822177f92cb7991b83149fb031
        const res = await axios.get("https://api.openweathermap.org/data/2.8/onecall?lat=33&lon=126&appid=d90e7385e1e42abff27b929ccddf2ac5&units=metric"
        );
        console.log(res);
        this.currentTemp = res.data.current.temp;
        this.currentDesc = res.data.current.weather[0].description;
        this.currentBarometer = res.data.current.pressure;
        this.currentFeelsLike = res.data.current.feels_like;
        this.currentHumidity = res.data.current.humidity;
        this.currentWeatherIcon = res.data.current.weather[0].icon;
    },
};


</script>

<style lang="scss" scoped>
.weather-box{
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    &__icon-box {
        display: flex;
        align-items: center;
        justify-content: center;

        gap: 48px;

        &__info{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;

            .temp{
                font-weight: 500;
                font-size: 88px;
            }

            .desc{
                font-weight: 100;
                font-size: 28px;

                margin-top: -12px;
            }

            .update {
                font-weight: 100;
            }
        }
        &__icon {
            height: 160px;

        }
    }
    &__detail{
        display: flex;
        align-items: center;
        justify-content: center;

        gap: 24px;
        margin-top: 16px;

        font-weight: 300;
    }
}
</style>